READ ME

Following are the steps for executing the program using executable file - 

1. Download JRE 8 from
 http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html

2. Download the a_star.jar file given by us placed inside folder "executable jar", from which the program gets executed.

3. Go to Command Prompt.
Go to the location where the a_star.jar file is downloaded (commad is cd "file location").
Type in the command java -jar a_star.jar

4. Program gets executed and asks for the below inputs from the user.
Locations and Connections File Location: (Give the location where the location and connection files are placed)
Start city: (Give your start city)
End City: ( Give the destinationg city)
Cities to exclude: (Give the list of cities separated by comma, that you want to exclude from the pathpath. Press enter if you don't want to exclude any city.)
Enter Heuristic type: ( Enter 1 for straight line distance heuristic and 2 for minimum number of nodes heuristic)

5. Solution path is displayed on the screen along with the cost estimates.



Following are the steps to compile the source code - 

1. Download Java 8 (JDK & JRE)

2. Download eclipse latest version

3. Import project folder AStar in eclipse

